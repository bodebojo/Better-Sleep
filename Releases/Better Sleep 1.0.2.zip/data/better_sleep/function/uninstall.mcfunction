scoreboard objectives remove better_sleep.numbers
scoreboard objectives remove better_sleep.sleeptimer
scoreboard objectives remove no_sleep
scoreboard objectives remove sleep_ping