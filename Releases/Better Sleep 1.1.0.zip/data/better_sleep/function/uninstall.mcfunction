scoreboard objectives remove better_sleep.numbers
scoreboard objectives remove better_sleep.sleeptimer
scoreboard objectives remove better_sleep.no_sleep
scoreboard objectives remove better_sleep.sleep_ping