
tick rate 20